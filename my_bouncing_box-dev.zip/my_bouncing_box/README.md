# Welcome to My Bouncing Box
***

## Task
TODO - What is the problem? And where is the challenge?
We need to make the div move and bounce in the edges of the screen, 

the challenge is in make it bounce when it reaches a certain position

## Description

I loocked how to make the div bounce when it reached a certain x and y position

## Installation
none
## Usage
```
./my_project argument1 argument2
```
node script.js

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
